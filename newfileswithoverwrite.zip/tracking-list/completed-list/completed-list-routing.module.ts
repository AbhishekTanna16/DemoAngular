import { CompletedListComponent } from './completed-list.component';
import { Routes, RouterModule } from '@angular/router';
import { NgModule } from '@angular/core';

const routes: Routes = [
  { path: '', component: CompletedListComponent }
];

@NgModule({
  imports: [
    RouterModule.forChild(routes)
  ],
  declarations: [
    CompletedListComponent
  ]
})
export class CompletedListRoutingModule { }
