import { CompletedListRoutingModule } from './completed-list-routing.module';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    CompletedListRoutingModule
  ]
})
export class CompletedListModule { }
