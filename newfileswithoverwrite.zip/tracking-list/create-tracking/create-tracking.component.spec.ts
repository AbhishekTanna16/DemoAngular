import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateTrackingComponent } from './create-tracking.component';

describe('CreateTrackingComponent', () => {
  let component: CreateTrackingComponent;
  let fixture: ComponentFixture<CreateTrackingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CreateTrackingComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateTrackingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
