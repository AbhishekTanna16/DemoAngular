
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CreateTrackingComponent } from './create-tracking.component';
const routes: Routes = [
  { path: '', component: CreateTrackingComponent }
];

@NgModule({
  imports: [
    RouterModule.forChild(routes)
  ],
  declarations: [
    CreateTrackingComponent
  ]
})
export class CreateTrackingRoutingModule { }
