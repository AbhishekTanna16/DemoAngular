import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-tracking',
  templateUrl: './create-tracking.component.html',
  styleUrls: ['./create-tracking.component.scss']
})
export class CreateTrackingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
