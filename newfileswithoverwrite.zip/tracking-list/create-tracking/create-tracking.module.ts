import { CreateTrackingRoutingModule } from './create-tracking-routing.module';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    CreateTrackingRoutingModule
  ]
})
export class CreateTrackingModule { }
