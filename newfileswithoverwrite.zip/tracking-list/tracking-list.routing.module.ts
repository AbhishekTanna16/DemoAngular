import { TrackingListComponent } from './tracking-list.component';
import { Route } from '@angular/router';
export const TRACKING_ROUTE: Route = {
  path: 'tracking',
  component: TrackingListComponent,
  children: [
    {
      path: 'create',
      loadChildren: () => import('./create-tracking/create-tracking.module').then(m => m.CreateTrackingModule)
    },
    {
      path: 'todo',
      loadChildren: () => import('./to-do/to-do.module').then(m => m.ToDoModule)
    },
    {
      path: 'active',
      loadChildren: () => import('./active-list/active-list.module').then(m => m.ActiveListModule)
    },
    {
      path: 'completed',
      loadChildren: () => import('./completed-list/completed-list.module').then(m => m.CompletedListModule)
    }
  ]
};
