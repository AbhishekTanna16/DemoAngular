import { Routes, RouterModule } from '@angular/router';
import { ActiveListComponent } from './active-list.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

const routes: Routes = [
  { path: '', component: ActiveListComponent }
];

@NgModule({
  imports: [
    RouterModule.forChild(routes)
  ],
  declarations: [
    ActiveListComponent
  ]
})
export class ActiveListRoutingModule { }
