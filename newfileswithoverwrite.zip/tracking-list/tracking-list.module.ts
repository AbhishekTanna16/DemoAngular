import { TrackingListComponent } from './tracking-list.component';
import { RouterModule } from '@angular/router';
import { TRACKING_ROUTE } from './tracking-list.routing.module';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';


@NgModule({
  declarations: [TrackingListComponent],
  imports: [
    CommonModule,
    RouterModule.forChild([TRACKING_ROUTE])
  ]
})
export class TrackingListModule { }
