import { RouterModule, Routes } from '@angular/router';
import { NgModule } from '@angular/core';
import { ToDoComponent } from './to-do.component';

const routes: Routes = [
  { path: '', component: ToDoComponent }
];

@NgModule({
  imports: [
    RouterModule.forChild(routes)
  ],
  declarations: [
    ToDoComponent
  ]
})
export class ToDoRoutingModule { }
