import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-tracking-list',
  templateUrl: './tracking-list.component.html',
  styleUrls: ['./tracking-list.component.scss']
})
export class TrackingListComponent implements OnInit {

  constructor(private router: Router) { }
  navLinks: any[];
  activeLinkIndex = -1;

  ngOnInit(): void {
    this.navLinks = [
      {
          label: 'create',
          link: '/tracking/create',
          index: 0
      }, {
          label: 'todo',
          link: '/tracking/todo',
          index: 1
      }, {
          label: 'active',
          link: '/tracking/active',
          index: 2
      },
      {
        label: 'completed',
        link: '/tracking/completed',
        index: 3
    },
   ];


    this.router.events.subscribe((res) => {
      debugger
        this.activeLinkIndex = this.navLinks.indexOf(this.navLinks.find(tab => tab.link === '/' + this.router.url));
    });
  }

}
