import { CustomFormValidators } from './../custom-form-validators';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Component } from '@angular/core';

@Component({
  selector: 'app-form-validation',
  templateUrl: './form-validation.component.html',
  styleUrls: ['./form-validation.component.scss']
})
export class FormValidationComponent {

  title = 'demo';
  validatorForm: FormGroup;
  submitted = false;

  constructor(
    private fb: FormBuilder,
    private customFormValidator: CustomFormValidators
  ) {
    this.validatorForm = this.fb.group({
      name: ['', [Validators.compose([Validators.required,Validators.minLength(2), this.customFormValidator.userNameValidator()])]],
      email: ['', [Validators.compose([Validators.required, this.customFormValidator.emailPatternAndValueValidator()])]]
    }
    );
  }
  get validatorFormControl() {
    return this.validatorForm?.controls;
  }
  isValueExists(type:string) {
    let isInValid = true
    if(type ==='name' && this.validatorFormControl?.name.value){
      const name = this.validatorFormControl.name.value
      const UserList = ['Bob'];
      isInValid = UserList.includes(name)

    }
    else if(type ==='email' && this.validatorFormControl?.email.value){
      const email = this.validatorFormControl.email.value
      const emailList = ['example.com'];
      isInValid =  emailList.includes(email.toLocaleLowerCase())

    }
    return isInValid
  }
  checkIsFormInValid(){
      return (!this.validatorForm?.valid)
  }

  onSubmit() {
    this.submitted = true;
    if (!this.checkIsFormInValid()) {
      alert('Form Submitted succesfully');
      console.table(this.validatorForm.value);
    }
  }

}
